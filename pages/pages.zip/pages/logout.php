<?php
require('../helper/function.php');
$auth = new Auth($db);
$auth->logout();
